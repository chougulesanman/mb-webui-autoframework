(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7016],{27561:function(e,t,n){var r=n(67990),a=/^\s+/;e.exports=function(e){return e?e.slice(0,r(e)+1).replace(a,""):e}},67990:function(e){var t=/\s/;e.exports=function(e){for(var n=e.length;n--&&t.test(e.charAt(n)););return n}},23279:function(e,t,n){var r=n(13218),a=n(7771),i=n(14841),o=Math.max,s=Math.min;e.exports=function(e,t,n){var c,l,u,f,h,_,d=0,g=!1,p=!1,m=!0;if("function"!=typeof e)throw TypeError("Expected a function");function v(t){var n=c,r=l;return c=l=void 0,d=t,f=e.apply(r,n)}function $(e){var n=e-_,r=e-d;return void 0===_||n>=t||n<0||p&&r>=u}function x(){var e,n,r,i=a();if($(i))return E(i);h=setTimeout(x,(e=i-_,n=i-d,r=t-e,p?s(r,u-n):r))}function E(e){return(h=void 0,m&&c)?v(e):(c=l=void 0,f)}function y(){var e,n=a(),r=$(n);if(c=arguments,l=this,_=n,r){if(void 0===h)return d=e=_,h=setTimeout(x,t),g?v(e):f;if(p)return clearTimeout(h),h=setTimeout(x,t),v(_)}return void 0===h&&(h=setTimeout(x,t)),f}return t=i(t)||0,r(n)&&(g=!!n.leading,u=(p="maxWait"in n)?o(i(n.maxWait)||0,t):u,m="trailing"in n?!!n.trailing:m),y.cancel=function(){void 0!==h&&clearTimeout(h),d=0,c=_=l=h=void 0},y.flush=function(){return void 0===h?f:E(a())},y}},33448:function(e,t,n){var r=n(44239),a=n(37005);e.exports=function(e){return"symbol"==typeof e||a(e)&&"[object Symbol]"==r(e)}},7771:function(e,t,n){var r=n(55639);e.exports=function(){return r.Date.now()}},14841:function(e,t,n){var r=n(27561),a=n(13218),i=n(33448),o=0/0,s=/^[-+]0x[0-9a-f]+$/i,c=/^0b[01]+$/i,l=/^0o[0-7]+$/i,u=parseInt;e.exports=function(e){if("number"==typeof e)return e;if(i(e))return o;if(a(e)){var t="function"==typeof e.valueOf?e.valueOf():e;e=a(t)?t+"":t}if("string"!=typeof e)return 0===e?e:+e;e=r(e);var n=c.test(e);return n||l.test(e)?u(e.slice(2),n?2:8):s.test(e)?o:+e}},44490:function(e,t,n){"use strict";n.d(t,{H4:function(){return s},r8:function(){return c},xn:function(){return o}});var r=n(66858);let a=(0,r.Ps)`
  fragment HEADER_SECTION on header_with_tabs {
    title
    subtitle
    description
    background {
      id
      title
      width
      height
    }
    logo {
      id
      width
      height
      title
    }
  }
`,i=(0,r.Ps)`
  fragment FORM on form {
    title
    subtitle
    button_label
    form_controls {
      form_control: form_control_id {
        formGroupName: form_group_name
        name
        type
        label
        placeholder
        required
        classes
        fcNote: fc_note
        radio_options {
          radio_option_id {
            value
            label
          }
        }
        validation_messages {
          item: validation_message_id {
            key
            message
            value
          }
        }
      }
    }
    formNote: form_note
  }
`,o=(0,r.Ps)`
  fragment BLOGS_CONTENT on blog_content {
    blog_categories {
      blog_categories_id {
        name
        slug
      }
    }
    title
    created
    content
    slug
    img {
      id
      width
      height
      title
    }
    mobile_img {
      id
      width
      height
      title
    }
    medium_img {
      id
      width
      height
      title
    }
    author {
      name
      img {
        id
        width
        height
        title
      }
    }
  }
`;(0,r.Ps)`
  ${i}
  fragment COMPLAINT_REQUEST on complaint_form {
    translations(filter: { languages_code: { code: { _eq: $locale } } }) {
      form: complaint_form_section {
        ...FORM
      }
    }
  }
`;let s=(0,r.Ps)`
  mutation createData(
    $locale: String
    $full_name: String
    $email: String
    $phone: String
    $address: String
    $incident_date: String
    $nature_of_complaint: String
    $related_to_complaint: String
    $complaint_description: String
  ) {
    create_complaint_requests_item(
      data: {
        locale: $locale
        full_name: $full_name
        email: $email
        phone: $phone
        address: $address
        incident_date: $incident_date
        nature_of_complaint: $nature_of_complaint
        related_to_complaint: $related_to_complaint
        complaint_description: $complaint_description
      }
    ) {
      id
      locale
      full_name
      email
      phone
      address
      incident_date
      nature_of_complaint
      related_to_complaint
      complaint_description
    }
  }
`;(0,r.Ps)`
  ${a}
  fragment BROKER_DEALER on broker_dealer {
    translations(filter: { languages_code: { code: { _eq: $locale } } }) {
      headerSection: section_header {
        ...HEADER_SECTION
      }
      content
    }
  }
`,(0,r.Ps)`
  ${a}
  fragment EXCHANGE_SERVICES on exchange_services {
    translations(filter: { languages_code: { code: { _eq: $locale } } }) {
      headerSection: header_section {
        ...HEADER_SECTION
      }
      content
    }
  }
`;let c=(0,r.Ps)`
  fragment SEARCH_INPUT on search_input {
    translations(filter: { languages_code: { code: { _eq: $locale } } }) {
      no_results
    }
  }
`},60409:function(e,t,n){"use strict";let r=new(n(66858)).g6(`${"https://cms.multibank.io".replace(/\/$/,"")}/graphql`);t.Z=r},75129:function(e,t,n){"use strict";var r=n(85893),a=n(11163),i=n(67294),o=n(60409),s=n(23279),c=n.n(s),l=n(93132),u=n.n(l),f=n(59632),h=n.n(f),_=n(2763),d=n(76317),g=n(23861),p=n(29144),m=n(44490),v=n(66858);t.Z=({graphqlQuery:e,inputClass:t="",inputWrapperClass:n="",placeholder:s="",baseURL:l=""})=>{let{locale:f,pathname:$}=(0,a.useRouter)(),[x,E]=(0,i.useState)(""),[y,S]=(0,i.useState)([]),[b,N]=(0,i.useState)(!1),[R,j]=(0,i.useState)("No Results");(0,i.useEffect)(()=>{let e=(0,v.Ps)`
      ${m.r8}
      query getData($locale: String) {
        search_input {
          ...SEARCH_INPUT
        }
      }
    `;(async()=>{let{search_input:{translations:t}}=await o.Z.request(e,{locale:"en"}),[{no_results:n}={}]=t;j(n)})()},[f]);let I=async t=>{if(!t.target.value||0===t.target.value.length)return S([]);E(t.target.value.trim());let n=await o.Z.request(e,{locale:"en",searchQuery:t.target.value,limit:10,page:0,offset:0,sort:"-created"}),r=Object.keys(n)?.[0];S(n[r])},w=(0,i.useMemo)(()=>c()(I,250),[]);return(0,r.jsxs)("div",{className:`${u().searchWrap} ${n}`,children:[(0,r.jsxs)("div",{className:`${u().searchInput} ${b?u().focused:""}`,children:[(0,r.jsx)(d.W1,{className:u().searchInputIcon}),(0,r.jsx)("input",{type:"text",className:`${u().searchInputInput} ${t}`,placeholder:s,onChange:w,onFocus:()=>N(!0),onBlur:()=>N(!1)}),0===y.length&&x.length>0&&b?(0,r.jsx)("span",{className:u().noResults,children:R}):(0,r.jsx)(r.Fragment,{})]}),b&&y?.length>0?(0,r.jsx)("div",{className:u().searchResults,children:(0,r.jsx)("div",{className:u().results,children:y?.map((e,t)=>{let[{slug:n},{slug:a}]=_.W5(e,"slug"),i=h()(e.title,RegExp(`(${x})`,"ig"),(e,t)=>r.jsx("em",{className:u().highlighted,children:e},e+t)),o=h()(_.bv(_.av(e.content),p.Z>480?300:100),RegExp(`(${x})`,"ig"),(e,t)=>r.jsx("em",{className:u().highlighted,children:e},e+t));return r.jsx(g.Z,{onMouseDown:e=>e.preventDefault(),href:`${""!==l?l:$}/${n}/${a}`,children:r.jsxs("div",{className:`${u().result} ${0===t?u().selected:""}`,children:[r.jsx("h2",{className:"text-white heading-3",children:i}),r.jsx("p",{className:"font-size-5 paragraph text-secondary",children:o})]})},e.slug)})})}):(0,r.jsx)(r.Fragment,{})]})}},40208:function(e,t,n){"use strict";var r=n(85893);t.Z=({sectionClassName:e="",containerClassname:t="",SectionBackground:n,children:a})=>(0,r.jsxs)("section",{className:`section ${e}`,children:[n&&(0,r.jsx)(n,{}),(0,r.jsx)("div",{className:`container ${t}`,children:a})]})},2763:function(e,t,n){"use strict";n.d(t,{W5:function(){return o},av:function(){return r},bv:function(){return a},vh:function(){return i}});let r=e=>null!==e&&""!==e&&(e=e.toString()).replace(/(<([^>]+)>)/gi,"").replace(/(&[^&]+;)/gi,""),a=(e,t)=>e.length>t?e.substring(0,t-3)+"...":e,i=({date:e,formatOption:t={day:"2-digit",month:"short",year:"numeric"}})=>new Date(e).toLocaleDateString("en-US",t),o=(e,t,n=[])=>{if(null!=e){if(Array.isArray(e))for(let r of e)o(r,t,n);else if("object"==typeof e)for(let r of Object.keys(e))r==t?n.push(e):o(e[r],t,n)}return n}},93132:function(e){e.exports={searchWrap:"search_searchWrap__9rn5U",searchInput:"search_searchInput__4fbEN",focused:"search_focused__DLzHO",noResults:"search_noResults__004XS",searchInputIcon:"search_searchInputIcon__zq61f",searchInputInput:"search_searchInputInput__Q_K5V",searchResults:"search_searchResults__YQoq2",results:"search_results__2O3G7",result:"search_result__qKvoj",selected:"search_selected__ZDd7j",paragraph:"search_paragraph__SL8KZ",highlighted:"search_highlighted__B_Jo2"}},59632:function(e){var t=function(e){var t=/[\\^$.*+?()[\]{}|]/g,n=RegExp(t.source);return e&&n.test(e)?e.replace(t,"\\$&"):e},n=function(e){return"string"==typeof e},r=function(e){var t=[];return e.forEach(function(e){Array.isArray(e)?t=t.concat(e):t.push(e)}),t};e.exports=function(e,a,i){return Array.isArray(e)||(e=[e]),r(e.map(function(e){return n(e)?function(e,r,a){var i=0,o=0;if(""===e)return e;if(!e||!n(e))throw TypeError("First argument to react-string-replace#replaceString must be a string");var s=r;s instanceof RegExp||(s=RegExp("("+t(s)+")","gi"));for(var c=e.split(s),l=1,u=c.length;l<u;l+=2){if(void 0===c[l]||void 0===c[l-1]){console.warn("reactStringReplace: Encountered undefined value during string replacement. Your RegExp may not be working the way you expect.");continue}o=c[l].length,i+=c[l-1].length,c[l]=a(c[l],l,i),i+=o}return c}(e,a,i):e}))}}}]);