(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[2447],{47585:function(e,i,o){(window.__NEXT_P=window.__NEXT_P||[]).push(["/about/global-presence",function(){return o(79932)}])},60409:function(e,i,o){"use strict";let t=new(o(66858)).g6(`${"https://cms.multibank.io".replace(/\/$/,"")}/graphql`);i.Z=t},79932:function(e,i,o){"use strict";o.r(i),o.d(i,{__N_SSG:function(){return p},default:function(){return h}});var t=o(85893),n=o(66858),a=o(60323);o(60409);var c=o(68979),s=o.n(c),l=o(10358);o(67294);var r=o(83687),_=o.n(r),f=o(52619),u=o(40208);let d=({item:e})=>(0,t.jsxs)("div",{className:_().item,children:[(0,t.jsx)("div",{className:_().imageWrap,children:(0,t.jsx)(f.Z,{file:e.building_silhoutte,fill:!0,alt:e.name,sizes:"(max-width: 768px) 100vw, (max-width: 991px) 50vw, 10vw"})}),(0,t.jsx)("div",{className:_().countryName,children:e.country_name}),(0,t.jsx)("div",{className:_().regulationName,children:e.name})]});var m=({our_presence_section:e})=>{let{title:i,subtitle:o,office_location_cards:n}=e;return(0,t.jsxs)(u.Z,{sectionClassName:_().officeLocationsSection,containerClassname:_().officeLocationsContainer,children:[(0,t.jsxs)("div",{className:_().sectionHeader,children:[(0,t.jsx)("div",{className:_().sectionSubtitle,children:i}),(0,t.jsx)("div",{className:_().sectionTitle,children:o})]}),(0,t.jsx)("div",{className:_().locationsWrap,children:n.map((e,i)=>(0,t.jsx)(d,{item:e},`location-card-${i}`))})]})};let g=({globalPresenceSection:e,ourPresenceSection:i})=>(0,t.jsxs)("div",{className:s().page,children:[e?(0,t.jsx)(l.Z,{global_presence_section:e}):(0,t.jsx)(t.Fragment,{}),i?(0,t.jsx)(m,{our_presence_section:i}):(0,t.jsx)(t.Fragment,{})]});(0,n.Ps)`
  query ($locale: String) {
    languages {
      code
    }
    global_presence_section {
      translations(filter: { languages_code: { code: { _eq: $locale } } }) {
        title
        subtitle
        description
        globe_flags {
          global_presence_maps_id {
            title
            highligted_title
            flag {
              id
              width
            }
            country_code
          }
        }
      }
    }
    our_presence_section {
      translations(filter: { languages_code: { code: { _eq: $locale } } }) {
        title
        subtitle
        office_location_cards {
          country_name
          name
          building_silhoutte {
            id
            width
            height
          }
        }
      }
    }
  }
`,g.layout=a.Z;var p=!0,h=g},83687:function(e){e.exports={officeLocationsSection:"office-locations_officeLocationsSection__Hisf3",officeLocationsContainer:"office-locations_officeLocationsContainer__IiW3e",locationsWrap:"office-locations_locationsWrap__Ii5Og",item:"office-locations_item__r9oRH",imageWrap:"office-locations_imageWrap__t0yCW",countryName:"office-locations_countryName__MpkIX",regulationName:"office-locations_regulationName__C7ODJ",sectionHeader:"office-locations_sectionHeader__ue0Oq",sectionSubtitle:"office-locations_sectionSubtitle__jGLM9",sectionTitle:"office-locations_sectionTitle__HMB4x"}},68979:function(e){e.exports={page:"global-presence_page__mpVz8"}}},function(e){e.O(0,[3737,5675,12,4270,9027,1664,7205,6858,5029,614,4342,358,2888,9774,179],function(){return e(e.s=47585)}),_N_E=e.O()}]);