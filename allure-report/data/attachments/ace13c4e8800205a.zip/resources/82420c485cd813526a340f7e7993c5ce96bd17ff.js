(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7832],{2384:function(t,e,n){(window.__NEXT_P=window.__NEXT_P||[]).push(["/support/contact-us",function(){return n(49407)}])},75850:function(t,e,n){"use strict";n.d(e,{Z:function(){return i}});var c=n(85893),a=n(80760),r=n.n(a);function i({children:t={},cardDivClass:e="",cardContentClass:n="",backgroundImage:a,...i}){return(0,c.jsxs)("div",{className:`${e} `+r().card,...i,children:[a?(0,c.jsx)("div",{className:r()["image-container"],children:a}):(0,c.jsx)(c.Fragment,{}),(0,c.jsx)("div",{className:`${n} `+r()["card-content"],children:t})]})}},83162:function(t,e,n){"use strict";n.d(e,{N:function(){return r},l:function(){return i}});var c=n(67294),a=n(2478);let r={contactUs:"contact_us_form_complete",partnership:"partnership_form_complete",rwaTokenRegister:"rwa_token_register_form_complete"},i=()=>{let t=(0,a.F)("GTMEventObj");return(0,c.useEffect)(()=>{if(void 0!==window.lintrk)try{window.dataLayer||(window.dataLayer=[]),window.dataLayer.some(e=>e?.event===t?.event)||(window.dataLayer?.push(t),window.localStorage?.removeItem("GTMEventObj"))}catch(t){console.error(t)}},[t]),null}},49407:function(t,e,n){"use strict";n.r(e),n.d(e,{__N_SSG:function(){return g}});var c=n(85893),a=n(60323),r=n(68373),i=n.n(r),s=n(67294),o=n(75850),d=n(66858),_=n(52619),l=n(39012),u=n(83162);let m=({contact_us:t})=>{let e=t?.card,n=t?.form,a={graphqlKey:"create_contact_us_requests_item",redirectionPath:"/thank-you",gtmObject:{keyToRead:"email",keyToSet:"email",eventName:u.N.contactUs}};return t?(0,c.jsx)(s.Fragment,{children:(0,c.jsx)("div",{className:"custom-section-wrapper",children:(0,c.jsx)("div",{className:"custom-section",children:(0,c.jsx)("div",{className:"custom-container",children:(0,c.jsxs)("div",{className:i()["contact-us-container"],children:[(0,c.jsx)("div",{className:i()["contact-us-column"],children:(0,c.jsxs)("div",{className:i().content,children:[(0,c.jsx)("h4",{className:"text-gold heading-5",children:t.subtitle}),(0,c.jsx)("h3",{className:"text-white heading-3",children:t.title}),(0,c.jsx)("p",{className:"text-secondary font-size-5",children:t.description}),n?(0,c.jsx)(l.c,{formConfig:a,mutation:p,form:n,submitButtonStyles:{width:"fit-content"}}):(0,c.jsx)(c.Fragment,{})]})}),(0,c.jsx)("div",{className:i()["contact-us-column"],children:e?(0,c.jsx)(o.Z,{cardDivClass:i()["card-div"],cardContentClass:i()["card-content"],children:(0,c.jsx)("div",{className:i().imageWrapper,children:(0,c.jsx)(_.Z,{file:e.image,sizes:"50vw",fill:!0})})}):(0,c.jsx)(c.Fragment,{})})]})})})})}):(0,c.jsx)(c.Fragment,{})},p=(0,d.Ps)`
  mutation createData(
    $locale: String
    $first_name: String
    $last_name: String
    $email: String
    $phone: String
    $exsiting_customer: String
    $topic: String
    $query: String
    $description: String
  ) {
    create_contact_us_requests_item(
      data: {
        locale: $locale
        first_name: $first_name
        last_name: $last_name
        email: $email
        phone: $phone
        existing_customer: $exsiting_customer
        topic: $topic
        query: $query
        description: $description
      }
    ) {
      id
      locale
      first_name
      last_name
      email
      phone
      existing_customer
      topic
      query
      description
    }
  }
`;m.layout=a.Z;var g=!0;e.default=m},80760:function(t){t.exports={card:"card_card__WrtKO","card-content":"card_card-content___JkV1","image-container":"card_image-container__N9Nwx"}},68373:function(t){t.exports={"contact-us-container":"contact-us_contact-us-container__3_nDr","contact-us-column":"contact-us_contact-us-column__CS24_",content:"contact-us_content__rz9aJ","card-div":"contact-us_card-div__jNdtI",imageWrapper:"contact-us_imageWrapper__WX9l9",backgroundImage:"contact-us_backgroundImage__2Zzjq","card-content":"contact-us_card-content__D7UCC","hand-image-wrapper":"contact-us_hand-image-wrapper__Cl_ky","card-text":"contact-us_card-text__jzI_H"}}},function(t){t.O(0,[8473,5675,12,4270,9027,1664,7205,9238,6858,8658,351,614,4342,9012,2888,9774,179],function(){return t(t.s=2384)}),_N_E=t.O()}]);