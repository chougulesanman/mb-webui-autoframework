(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[5358],{73212:function(e,n,t){"use strict";t.d(n,{Y2:function(){return s},jn:function(){return a},kB:function(){return i}});var r=t(66858);let a=(0,r.Ps)`
  mutation createData(
    $locale: String
    $full_name: String
    $email: String
    $phone: String
    $referral_code: String
    $inquiry: String
  ) {
    create_vip_requests_item(
      data: {
        locale: $locale
        full_name: $full_name
        email: $email
        phone: $phone
        referral_code: $referral_code
        inquiry: $inquiry
      }
    ) {
      id
      locale
      full_name
      email
      phone
      referral_code
      inquiry
    }
  }
`,i=(0,r.Ps)`
  mutation createData(
    $locale: String
    $company_name: String
    $contact_person: String
    $email: String
    $phone: String
    $industry: String
    $company_registration_location: String
    $inquiry: String
  ) {
    create_corporate_requests_item(
      data: {
        locale: $locale
        company_name: $company_name
        contact_person: $contact_person
        email: $email
        phone: $phone
        industry: $industry
        company_registration_location: $company_registration_location
        inquiry: $inquiry
      }
    ) {
      id
      locale
      company_name
      contact_person
      email
      phone
      industry
      company_registration_location
      inquiry
    }
  }
`,s=(0,r.Ps)`
  mutation createData(
    $locale: String
    $full_name: String
    $email: String
    $phone: String
    $pair_required: String
    $amount: Int
    $additional_comments: String
  ) {
    create_otc_requests_item(
      data: {
        locale: $locale
        full_name: $full_name
        email: $email
        phone: $phone
        pair_required: $pair_required
        amount: $amount
        additional_comments: $additional_comments
      }
    ) {
      id
      locale
      full_name
      email
      phone
      pair_required
      amount
      additional_comments
    }
  }
`},1146:function(e,n,t){"use strict";t.d(n,{M:function(){return o}});var r=t(85893),a=t(59795),i=t.n(a),s=t(39012);let o=({form:e,formConfig:n,mutation:t,error:a,validationMessages:o,stylesConfig:c={},watchConfig:l,initialValues:_={}})=>{if(!e)return(0,r.jsx)(r.Fragment,{});let{subtitleClassName:d,formCardClassName:m}=c;return(0,r.jsx)("div",{id:"partnership-form",className:i()["section-container"],children:(0,r.jsxs)("div",{className:`${i()["form-card"]} ${m}`,children:[(0,r.jsxs)("div",{className:i()["card-header"],children:[(0,r.jsx)("h3",{className:`text-white ${i().title}`,children:e.title}),(0,r.jsx)("h4",{className:d||i().subtitle,children:e.subtitle})]}),e?(0,r.jsx)(s.c,{form:e,formConfig:n,mutation:t,error:a,validationMessages:o,watchConfig:l,initialValues:_}):(0,r.jsx)(r.Fragment,{})]})})}},35140:function(e,n,t){"use strict";t.d(n,{E:function(){return _}});var r=t(85893),a=t(48744),i=t.n(a),s=t(84726),o=t(29238),c=t(52619),l=t(42708);let _=({partnershipSection:e})=>{let{ref:n,inView:t}=(0,l.YD)(),{title:a,sectionHeading:_,description:d,terms:m,image:p,secondaryImage:h,backgroundImage:u,note:g,contentPosition:x,backgroundColor:f="transparent"}=e,w=["Pattern01"],j=a?(0,s._)(a,{replaceWith:{start:'<span class="text-gold">',end:"</span>"}}):"",$=({image:e,imageClassName:n=""})=>e?(0,r.jsx)(c.Z,{file:e,fill:!0,style:{objectFit:"contain"},sizes:"80vw, (min-width:481px) 60vw, (min-width:1200px) 45w",className:n}):(0,r.jsx)(r.Fragment,{});return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)("div",{ref:n,className:`${i()["partnership-section"]} slide-up ${t?"in-view":""}`,style:{background:f},children:[(0,r.jsx)(({backgroundImage:e})=>e?(0,r.jsx)("div",{className:"background-image",children:(0,r.jsx)(c.Z,{file:e,fill:!0,sizes:"100vw",skeletonLoading:!1,style:{objectFit:w.includes(e.title)?"contain":"cover"}})}):(0,r.jsx)(r.Fragment,{}),{backgroundImage:u}),(0,r.jsxs)("div",{className:"custom-container",children:[_?(0,r.jsx)("div",{className:i().heading,children:(0,r.jsx)("h3",{className:`text-gold ${i()["section-title"]}`,children:_})}):(0,r.jsx)(r.Fragment,{}),(0,r.jsxs)("div",{className:`${i()["main-container"]} ${"left"===x?i()["content-position-left"]:i()["content-position-right"]}`,children:[(0,r.jsxs)("div",{className:i().content,children:[(0,r.jsx)("h2",{className:i().title,dangerouslySetInnerHTML:{__html:(0,o.sanitize)(j)}}),d?(0,r.jsx)("p",{className:i().description,children:d}):(0,r.jsx)(r.Fragment,{}),(0,r.jsx)(({terms:e})=>e&&0!==e.length?(0,r.jsx)(r.Fragment,{children:(0,r.jsx)("div",{className:i()["terms-list"],children:e.map((e,n)=>(0,r.jsx)("span",{className:`${i()["term-item"]} ${i().description}`,children:e},n))})}):(0,r.jsx)(r.Fragment,{}),{terms:m?.terms})]}),(0,r.jsxs)("div",{className:i()["image-wrapper"],children:[(0,r.jsx)($,{image:h}),(0,r.jsx)($,{image:p,imageClassName:i()["blur-effect"]}),(0,r.jsx)($,{image:p})]})]}),g?(0,r.jsx)("div",{className:i().note,dangerouslySetInnerHTML:{__html:(0,o.sanitize)(g)}}):(0,r.jsx)(r.Fragment,{})]})]})})}},14884:function(e,n,t){"use strict";t.d(n,{H:function(){return f}});var r=t(85893),a=t(19200),i=t.n(a);t(84726),t(29238);var s=t(52619),o=t(73261),c=t(42708),l=t(95841),_=t(17857),d=t(97015),m=t.n(d),p=({from:e,to:n})=>(0,r.jsxs)("div",{className:m().wrapper,children:[(0,r.jsx)("div",{className:m().polygon}),(0,r.jsx)(_.ZP,{className:m().number,start:e,end:n,delay:2.8})]}),h=t(99064),u=t(96619),g=t(25675),x=t.n(g);let f=({slug:e,goldTitle:n,title:t,subtitle:a,description:_,image1:d,image2:m,image3:g,backgroundImage:f,button:w,badge:j,derivativesCounter:$,enableGreenRedGlow:b=!1,customClassNames:v={},showScrollIcon:N=!1})=>{let{ref:y,inView:S}=(0,c.YD)({triggerOnce:!0}),F=({image:e,imageClassName:n})=>e?(0,r.jsx)(s.Z,{file:e,fill:!0,sizes:"80vw, (min-width:481px) 60vw, (min-width:1200px) 45w",className:`${i()[n]} ${i()[e.className]}`,priority:!0}):(0,r.jsx)(r.Fragment,{});return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)("div",{ref:y,className:`${i()["partnership-banner"]} ${v.mainSection} fade-in ${S?"in-view":""}`,children:[(0,r.jsx)(()=>{if(!f)return(0,r.jsx)(r.Fragment,{});let e=v.backgroundImageClass||"";return(0,r.jsx)("div",{className:`background-image ${i()[e]} ${i()[f.className]}`,children:(0,r.jsx)(s.Z,{file:f,fill:!0,sizes:"100vw, (min-width:481px) 60vw, (min-width:1200px) 50w",skeletonLoading:!1,priority:!0})})},{backgroundImage:f}),(0,r.jsx)("div",{className:"custom-container extra-padding-on-huge",children:(0,r.jsxs)("div",{className:`${i()["main-container"]} ${i()[v.mainContainer]}`,children:[(0,r.jsxs)("div",{className:`${i().content} ${i()[v.content]}`,children:[n?(0,r.jsx)("h3",{className:`${i().goldTitle} text-gold`,children:n}):(0,r.jsx)(r.Fragment,{}),(0,r.jsx)("h2",{className:`${i().title} ${v.title}`,dangerouslySetInnerHTML:(0,u.P)(t,"text-yellow")}),a?(0,r.jsx)("h3",{className:`${i().subtitle} ${v.subtitle}`,dangerouslySetInnerHTML:(0,u.P)(a,"text-green")}):(0,r.jsx)(r.Fragment,{}),_?(0,r.jsx)("p",{className:`${i().description} ${v.description}`,children:_}):(0,r.jsx)(r.Fragment,{}),(0,r.jsxs)("div",{className:i().actions,children:[w?(0,r.jsx)(o.Z,{onClick:()=>(0,l.k)("#partnership-form"),title:w?.label,href:w?.url}):(0,r.jsx)(r.Fragment,{}),j?(0,r.jsx)(h.H,{...j,children:j.title}):(0,r.jsx)(r.Fragment,{})]})]}),(0,r.jsxs)("div",{className:i()["image-wrapper"],children:[(0,r.jsx)(F,{image:d,imageClassName:v.image1ClassName}),b?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)("div",{className:`${i().glow} ${i()["green-glow"]}`}),(0,r.jsx)("div",{className:`${i().glow} ${i()["red-glow"]}`})]}):(0,r.jsx)(r.Fragment,{}),(0,r.jsx)(F,{image:m,imageClassName:v.image2ClassName}),(0,r.jsx)(F,{image:g,imageClassName:v.image3ClassName}),$?(0,r.jsx)(p,{...$}):(0,r.jsx)(r.Fragment,{})]})]})}),N?(0,r.jsx)(x(),{src:"/images/shared/scroll-down-icon.gif",alt:"scroll-down-icon",width:50,height:50,className:i().scrollDownIcon}):(0,r.jsx)(r.Fragment,{})]})})}},83162:function(e,n,t){"use strict";t.d(n,{N:function(){return i},l:function(){return s}});var r=t(67294),a=t(2478);let i={contactUs:"contact_us_form_complete",partnership:"partnership_form_complete",rwaTokenRegister:"rwa_token_register_form_complete"},s=()=>{let e=(0,a.F)("GTMEventObj");return(0,r.useEffect)(()=>{if(void 0!==window.lintrk)try{window.dataLayer||(window.dataLayer=[]),window.dataLayer.some(n=>n?.event===e?.event)||(window.dataLayer?.push(e),window.localStorage?.removeItem("GTMEventObj"))}catch(e){console.error(e)}},[e]),null}},84726:function(e,n,t){"use strict";t.d(n,{_:function(){return a}});let r={"{{":"}}","<<":">>","{{{":"}}}"},a=(e,n)=>{let{delimiter:t={start:"{{",end:"}}"},replaceWith:a}=n;if(r[t.start]!==t.end)throw Error(`the closing boundary " ${t.end} " does not match the opening " ${t.start} " `);let i=e=>RegExp(e,"gi");return e.replace(i(t.start),a.start).replace(i(t.end),a.end)}},96619:function(e,n,t){"use strict";t.d(n,{P:function(){return i}});var r=t(84726),a=t(29238);function i(e,n){let t=(0,r._)(e,{replaceWith:{start:`<span class="gradient-text !text-transparent ${n}">`,end:"</span>"}});return{__html:(0,a.sanitize)(t)}}},95841:function(e,n,t){"use strict";t.d(n,{A:function(){return r},k:function(){return a}});let r=(e,n)=>{let t=document.querySelector(e);t&&document.querySelectorAll(n).forEach(e=>{e.addEventListener("click",function(e){e.preventDefault(),e.stopPropagation(),t.scrollIntoView({behavior:"smooth"})})})},a=e=>{let n=document.querySelector(e);n&&n.scrollIntoView({behavior:"smooth"})}},59795:function(e){e.exports={"section-container":"partnership-form_section-container__uccc4","form-card":"partnership-form_form-card__B9gio","card-header":"partnership-form_card-header__2mE1r",title:"partnership-form_title__p_qJe",subtitle:"partnership-form_subtitle__eH34x"}},48744:function(e){e.exports={"partnership-section":"partnership-section_partnership-section__dPCcH",heading:"partnership-section_heading__nLMy7","section-title":"partnership-section_section-title__xCU4B","main-container":"partnership-section_main-container__ms4z0",content:"partnership-section_content__FVJEW",title:"partnership-section_title__Z8Bh3",description:"partnership-section_description__6qEf6","terms-list":"partnership-section_terms-list__ddybN","term-item":"partnership-section_term-item__tAUSj","image-wrapper":"partnership-section_image-wrapper__37DtK","blur-effect":"partnership-section_blur-effect__4rC6o","content-position-left":"partnership-section_content-position-left__awsYS","content-position-right":"partnership-section_content-position-right__NzW1m",note:"partnership-section_note__0It_D"}},97015:function(e){e.exports={wrapper:"derivatives-custom-counter_wrapper__XIVTs",showUp:"derivatives-custom-counter_showUp__SqLqm",polygon:"derivatives-custom-counter_polygon__XkhTX",scaleInOut:"derivatives-custom-counter_scaleInOut__gOI_N",number:"derivatives-custom-counter_number__Gy00w"}},19200:function(e){e.exports={"partnership-banner":"shared-banner-section_partnership-banner__RnPJ_","bars-background":"shared-banner-section_bars-background__EbegH",wavesBackground:"shared-banner-section_wavesBackground__2239_","scale-hex":"shared-banner-section_scale-hex__oIwA2","white-glow":"shared-banner-section_white-glow__82I3I","main-container":"shared-banner-section_main-container__3XLB4",content:"shared-banner-section_content__i0gM2",goldTitle:"shared-banner-section_goldTitle__vgBRS",title:"shared-banner-section_title__eZFhx","secondary-title":"shared-banner-section_secondary-title__BihAG",subtitle:"shared-banner-section_subtitle__LpREx",description:"shared-banner-section_description__RQsUR",actions:"shared-banner-section_actions__yKN8K","items-flex-start":"shared-banner-section_items-flex-start__Zd0tQ","image-wrapper":"shared-banner-section_image-wrapper__dzt73",glow:"shared-banner-section_glow__Y2MYF","green-glow":"shared-banner-section_green-glow__WQs_j","red-glow":"shared-banner-section_red-glow__hoDDG","animate-zoom-in-out":"shared-banner-section_animate-zoom-in-out__SrSPN",zoomInOut:"shared-banner-section_zoomInOut__SScTV","rotate-right-down":"shared-banner-section_rotate-right-down__K09fR",rotateRightDown:"shared-banner-section_rotateRightDown__SRrad","rotate-left-down":"shared-banner-section_rotate-left-down__vTV_g",rotateLeftDown:"shared-banner-section_rotateLeftDown__wiHZ7","main-container-reverse":"shared-banner-section_main-container-reverse__AXOJU",scrollDownIcon:"shared-banner-section_scrollDownIcon__HxZ5l",showUp:"shared-banner-section_showUp__XSV9O",showUp2:"shared-banner-section_showUp2__fP9rs",showUp3:"shared-banner-section_showUp3__6_Cd9"}}}]);