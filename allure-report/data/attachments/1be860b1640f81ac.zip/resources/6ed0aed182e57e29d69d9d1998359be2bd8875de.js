/*! For license information please see serviceworker.js.LICENSE.txt */
importScripts(
  'https://cdn.moengage.com/release/dc_2/serviceworker_cdn.min.latest.js',
)
