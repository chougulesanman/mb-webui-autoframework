(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7859],{82270:function(e,t,n){(window.__NEXT_P=window.__NEXT_P||[]).push(["/about/blog/[...slug]",function(){return n(4238)}])},4238:function(e,t,n){"use strict";n.r(t),n.d(t,{__N_SSG:function(){return P},default:function(){return q}});var s=n(85893),o=n(60323),a=n(61227),i=n.n(a),r=n(66858),c=n(60409),l=n(11163),g=n(28176),_=n(40208),d=n(76871),u=n(47348),p=n(64688),h=n(44490),m=n(59235),f=n(52619),x=n(68280),j=n(25700),S=n.n(j),b=n(76317),$=n(2763),N=n(67294),C=n(29144),y=n(69948),I=()=>{let{postContent:e={},relatedContents:{blog_content:t=[]}={},blogPage:n={}}=(0,m.Z)()||{},{related_posts_title:o=""}=n,{author:a={},content:i="",title:r="",created:c="",img:l={},mobile_img:g={}}=e?.blog_content?.[0]||{};(0,N.useEffect)(()=>{document.getElementById("postMainSection").addEventListener("click",e=>{e.preventDefault(),"a"===e.target.tagName.toLowerCase()&&window.open(e.target.getAttribute("href"),"_blank")})},[]);let{width:_}=(0,C.Z)(),d=(0,N.useMemo)(()=>_<=450?g:l,[l,g,_]);return(0,s.jsxs)("section",{id:"postMainSection",children:[(0,s.jsxs)("div",{className:S().headerSection,children:[(0,s.jsx)("h1",{className:"text-white heading-3",children:r}),(0,s.jsxs)("div",{className:S().postInfo,children:[(0,s.jsx)("div",{className:S().authorImgWrapper,children:(0,s.jsx)(f.Z,{file:a?.img,fill:!0})}),(0,s.jsx)("p",{className:"text-white",children:a?.name}),_<=450?(0,s.jsx)(s.Fragment,{}):(0,s.jsx)(b.bq,{}),(0,s.jsx)("p",{className:"text-secondary",children:(0,$.vh)({date:c})})]})]}),(0,s.jsx)("div",{className:S().postImgWrapper,children:(0,s.jsx)(f.Z,{file:d,fill:!0})}),(0,s.jsx)(x.Z,{className:S().contentSection,content:i},i),(0,s.jsxs)("div",{className:S().relatedPosts,children:[(0,s.jsx)("h1",{className:"text-gold heading-3",children:o}),t.map((e,t)=>(0,s.jsx)(y.Z,{containerClassName:S().postContainer,post:e},`index-${t}`))]})]})},Z=n(75129),v=n(29796);let w=(0,r.Ps)`
  ${h.xn}
  query getData(
    $locale: String
    $searchQuery: String
    $sort: [String]
    $limit: Int
    $offset: Int
    $page: Int
    $categorySlug: String
  ) {
    blog_content(
      filter: {
        blog_categories: {
          _and: [
            { blog_categories_id: { slug: { _eq: $categorySlug } } }
            {
              blog_categories_id: {
                blog_category: { languages_code: { code: { _eq: $locale } } }
              }
            }
          ]
        }
      }
      limit: $limit
      page: $page
      search: $searchQuery
      offset: $offset
      sort: $sort
    ) {
      ...BLOGS_CONTENT
    }
  }
`,E=(0,r.Ps)`
  ${h.xn}
  query getData(
    $locale: String
    $searchQuery: String
    $sort: [String]
    $limit: Int
    $offset: Int
    $page: Int
  ) {
    blog_content(
      filter: {
        blog_categories: {
          blog_categories_id: {
            blog_category: { languages_code: { code: { _eq: $locale } } }
          }
        }
      }
      limit: $limit
      page: $page
      search: $searchQuery
      offset: $offset
      sort: $sort
    ) {
      ...BLOGS_CONTENT
    }
  }
`,M=e=>{let{query:t,asPath:n}=(0,l.useRouter)(),{slug:o}=t||{},a=o?.length===1,r=o?.length>1,{search_placeholder:h=""}=e?.blogPage||{},{width:m}=(0,C.Z)(),f=m<=1200,x=e.locale,{page:j=0}=t,[S,b]=(0,N.useState)({});(0,N.useEffect)(()=>{(async()=>{b(await c.Z.request(w,{locale:x,searchQuery:"",limit:v.LIMIT_PER_PAGE,page:+j,offset:0,sort:"-created",categorySlug:o?.[0]||" "}))})()},[j,t,x,o]);let $=e?.blogPage?.blog_categories?.filter(e=>e.slug==o)?.[0]?.blog_contents_func?.count||0;return(0,s.jsxs)("div",{className:i().mainSection,children:[(0,s.jsx)(g.Z,{SearchComponent:(0,s.jsx)(Z.Z,{placeholder:h,baseURL:"/about/blog",graphqlQuery:E},n)}),f?(0,s.jsx)("div",{className:i().tabletAndMobileCategoriesContainer,children:(0,s.jsx)(p.Z,{})}):(0,s.jsx)(s.Fragment,{}),(0,s.jsxs)(_.Z,{sectionClassName:i().section,containerClassname:i()["section-container"],children:[(0,s.jsxs)("div",{className:i()["main-section"],children:[a?(0,s.jsx)(d.Z,{blogContent:S,dataCount:$},j):(0,s.jsx)(s.Fragment,{}),r?(0,s.jsx)(I,{}):(0,s.jsx)(s.Fragment,{})]}),(0,s.jsxs)("div",{className:i()["sidebar-section"],children:[(0,s.jsx)(u.Z,{}),f?(0,s.jsx)(s.Fragment,{}):(0,s.jsx)(p.Z,{})]})]})]})};M.layout=o.Z;var P=!0,q=M},25700:function(e){e.exports={headerSection:"postContentMainSection_headerSection__Xz5WR",postInfo:"postContentMainSection_postInfo__ZXg6e",authorImgWrapper:"postContentMainSection_authorImgWrapper__on5mS",postImgWrapper:"postContentMainSection_postImgWrapper__OhRED",contentSection:"postContentMainSection_contentSection__cm7r9",relatedPosts:"postContentMainSection_relatedPosts__XgHTy",postContainer:"postContentMainSection_postContainer__drMjn"}}},function(e){e.O(0,[5675,12,4270,9027,1664,7205,6858,614,4342,7016,4040,2888,9774,179],function(){return e(e.s=82270)}),_N_E=e.O()}]);