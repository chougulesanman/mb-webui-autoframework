(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6343],{39686:function(e,t,n){(window.__NEXT_P=window.__NEXT_P||[]).push(["/about/gcc/complaint-policy",function(){return n(19769)}])},44490:function(e,t,n){"use strict";n.d(t,{H4:function(){return l},r8:function(){return c},xn:function(){return a}});var r=n(66858);let i=(0,r.Ps)`
  fragment HEADER_SECTION on header_with_tabs {
    title
    subtitle
    description
    background {
      id
      title
      width
      height
    }
    logo {
      id
      width
      height
      title
    }
  }
`,o=(0,r.Ps)`
  fragment FORM on form {
    title
    subtitle
    button_label
    form_controls {
      form_control: form_control_id {
        formGroupName: form_group_name
        name
        type
        label
        placeholder
        required
        classes
        fcNote: fc_note
        radio_options {
          radio_option_id {
            value
            label
          }
        }
        validation_messages {
          item: validation_message_id {
            key
            message
            value
          }
        }
      }
    }
    formNote: form_note
  }
`,a=(0,r.Ps)`
  fragment BLOGS_CONTENT on blog_content {
    blog_categories {
      blog_categories_id {
        name
        slug
      }
    }
    title
    created
    content
    slug
    img {
      id
      width
      height
      title
    }
    mobile_img {
      id
      width
      height
      title
    }
    medium_img {
      id
      width
      height
      title
    }
    author {
      name
      img {
        id
        width
        height
        title
      }
    }
  }
`;(0,r.Ps)`
  ${o}
  fragment COMPLAINT_REQUEST on complaint_form {
    translations(filter: { languages_code: { code: { _eq: $locale } } }) {
      form: complaint_form_section {
        ...FORM
      }
    }
  }
`;let l=(0,r.Ps)`
  mutation createData(
    $locale: String
    $full_name: String
    $email: String
    $phone: String
    $address: String
    $incident_date: String
    $nature_of_complaint: String
    $related_to_complaint: String
    $complaint_description: String
  ) {
    create_complaint_requests_item(
      data: {
        locale: $locale
        full_name: $full_name
        email: $email
        phone: $phone
        address: $address
        incident_date: $incident_date
        nature_of_complaint: $nature_of_complaint
        related_to_complaint: $related_to_complaint
        complaint_description: $complaint_description
      }
    ) {
      id
      locale
      full_name
      email
      phone
      address
      incident_date
      nature_of_complaint
      related_to_complaint
      complaint_description
    }
  }
`;(0,r.Ps)`
  ${i}
  fragment BROKER_DEALER on broker_dealer {
    translations(filter: { languages_code: { code: { _eq: $locale } } }) {
      headerSection: section_header {
        ...HEADER_SECTION
      }
      content
    }
  }
`,(0,r.Ps)`
  ${i}
  fragment EXCHANGE_SERVICES on exchange_services {
    translations(filter: { languages_code: { code: { _eq: $locale } } }) {
      headerSection: header_section {
        ...HEADER_SECTION
      }
      content
    }
  }
`;let c=(0,r.Ps)`
  fragment SEARCH_INPUT on search_input {
    translations(filter: { languages_code: { code: { _eq: $locale } } }) {
      no_results
    }
  }
`},72874:function(e,t,n){"use strict";n.d(t,{A:function(){return l}});var r=n(85893),i=n(7995),o=n.n(i),a=n(29238);let l=({documentalPageProps:e})=>{if(!e[0])return(0,r.jsx)(r.Fragment,{});let{translations:t}=e[0],{title:n,content:i}=t[0]||{};return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)("div",{className:"custom-container",children:[(0,r.jsx)("div",{className:o().heading,children:(0,r.jsx)("h2",{className:"text-gold",children:n})}),(0,r.jsx)("div",{className:"text-white ",children:(0,r.jsx)("div",{className:o()["content-wrapper"],dangerouslySetInnerHTML:{__html:(0,a.sanitize)(i)}})})]})})}},1146:function(e,t,n){"use strict";n.d(t,{M:function(){return l}});var r=n(85893),i=n(59795),o=n.n(i),a=n(39012);let l=({form:e,formConfig:t,mutation:n,error:i,validationMessages:l,stylesConfig:c={},watchConfig:s,initialValues:_={}})=>{if(!e)return(0,r.jsx)(r.Fragment,{});let{subtitleClassName:d,formCardClassName:m}=c;return(0,r.jsx)("div",{id:"partnership-form",className:o()["section-container"],children:(0,r.jsxs)("div",{className:`${o()["form-card"]} ${m}`,children:[(0,r.jsxs)("div",{className:o()["card-header"],children:[(0,r.jsx)("h3",{className:`text-white ${o().title}`,children:e.title}),(0,r.jsx)("h4",{className:d||o().subtitle,children:e.subtitle})]}),e?(0,r.jsx)(a.c,{form:e,formConfig:t,mutation:n,error:i,validationMessages:l,watchConfig:s,initialValues:_}):(0,r.jsx)(r.Fragment,{})]})})}},83162:function(e,t,n){"use strict";n.d(t,{N:function(){return o},l:function(){return a}});var r=n(67294),i=n(2478);let o={contactUs:"contact_us_form_complete",partnership:"partnership_form_complete",rwaTokenRegister:"rwa_token_register_form_complete"},a=()=>{let e=(0,i.F)("GTMEventObj");return(0,r.useEffect)(()=>{if(void 0!==window.lintrk)try{window.dataLayer||(window.dataLayer=[]),window.dataLayer.some(t=>t?.event===e?.event)||(window.dataLayer?.push(e),window.localStorage?.removeItem("GTMEventObj"))}catch(e){console.error(e)}},[e]),null}},19769:function(e,t,n){"use strict";n.r(t),n.d(t,{__N_SSG:function(){return u}});var r=n(85893),i=n(60323),o=n(72874),a=n(5517),l=n.n(a),c=n(1146),s=n(67294),_=n(44490),d=n(95841);n(83162);let m=({documental_page:e,complaintForm:t})=>{let n=t?.translations[0]?.form;return(0,s.useEffect)(()=>{(0,d.A)("#form","#scroll-to-form")},[e]),(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(o.A,{documentalPageProps:e}),(0,r.jsx)("div",{className:l()["complaint-request-page"],id:"form",children:(0,r.jsx)(c.M,{form:n,stylesConfig:{subtitleClassName:l()["form-subtitle"]},formConfig:{graphqlKey:"create_complaint_requests_item",redirectionPath:"/thank-you"},mutation:_.H4})})]})};m.layout=i.Z;var u=!0;t.default=m},95841:function(e,t,n){"use strict";n.d(t,{A:function(){return r},k:function(){return i}});let r=(e,t)=>{let n=document.querySelector(e);n&&document.querySelectorAll(t).forEach(e=>{e.addEventListener("click",function(e){e.preventDefault(),e.stopPropagation(),n.scrollIntoView({behavior:"smooth"})})})},i=e=>{let t=document.querySelector(e);t&&t.scrollIntoView({behavior:"smooth"})}},7995:function(e){e.exports={heading:"documental-page_heading__c6gG1","content-wrapper":"documental-page_content-wrapper__N6Ie2"}},59795:function(e){e.exports={"section-container":"partnership-form_section-container__uccc4","form-card":"partnership-form_form-card__B9gio","card-header":"partnership-form_card-header__2mE1r",title:"partnership-form_title__p_qJe",subtitle:"partnership-form_subtitle__eH34x"}},5517:function(e){e.exports={"complaint-request-page":"complaint-policy_complaint-request-page___x1fu","form-subtitle":"complaint-policy_form-subtitle__a6U_T"}}},function(e){e.O(0,[8473,5675,12,4270,9027,1664,7205,9238,6858,8658,351,614,4342,9012,2888,9774,179],function(){return e(e.s=39686)}),_N_E=e.O()}]);